import pathlib, re
root = pathlib.Path('/data/pullup/src')
html = (root/'index.html').read_text()
css = (root/'style.css').read_text()
js = '\n'.join(p.read_text() for p in sorted((root/'js').glob('*.js')))
out = html.replace('/*@@CSS@@*/', css).replace('/*@@JS@@*/', js)
pathlib.Path('/data/pullup/dist/pullup.html').write_text(out)
print('built', len(out), 'bytes')
