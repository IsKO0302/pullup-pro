/* ================= Settings, data management, demo data ================= */
ROUTES.settings = {
  title: 'Настройки',
  render() {
    const p = S.profile, vibOk = 'vibrate' in navigator, kb = storageSize() / 1024;
    const sw = (f, t, sub, dis = false) => `<label class="switch"><input type="checkbox" data-chg="setSw" data-f="${f}" ${p[f] ? 'checked' : ''} ${dis ? 'disabled' : ''}><i></i><span><b class="small">${t}</b>${sub ? `<span class="tiny muted" style="display:block">${sub}</span>` : ''}</span></label>`;
    return pageHead('Настройки', 'Профиль, цели, звук и данные. Всё хранится только в этом браузере (localStorage) — без регистрации и серверов.', '', 'Профиль и данные') + `
    <div class="grid g2">
      <div class="card stack l"><div class="card-head" style="margin:0"><h3>${ico('user')}Профиль</h3></div>
        <div class="form-grid">
          <label class="field"><span>Имя</span><input class="inp" maxlength="30" value="${esc(p.name)}" placeholder="Как к вам обращаться" data-chg="setP" data-f="name"></label>
          <div class="field"><span>Вес тела, кг</span>${stepper('set-bw', p.bodyweight, 30, 250, 0.5, 'data-chg="setP" data-f="bodyweight"')}</div>
          <div class="field"><span>Текущий максимум подтягиваний</span>${stepper('set-max', p.maxPullups, 0, 100, 1, 'data-chg="setMax"')}</div>
          <label class="field"><span>Программа</span><select class="inp" data-chg="setP" data-f="program">${PROGRAMS.map(P => `<option value="${P.id}" ${P.id === p.program ? 'selected' : ''}>${P.name} — ${P.range}</option>`).join('')}</select></label>
        </div>
        <div class="small muted">Вес тела нужен для расчёта тоннажа. Максимум точнее всего обновлять через <button class="link-btn" data-act="testWizard">тест уровня</button>.</div>
      </div>
      <div class="card stack l"><div class="card-head" style="margin:0"><h3>${ico('target')}Цели</h3></div>
        <div class="field"><span>Подтягиваний в день</span>${stepper('set-goal', p.goalDaily, 0, 500, 5, 'data-chg="setP" data-f="goalDaily"')}<span class="tiny muted">0 — без дневной цели. Цель не учитывается в дни восстановления.</span></div>
        <div class="field"><span>Тренировок в неделю</span>${segBtns('setWeekly', [[2, '2'], [3, '3'], [4, '4'], [5, '5']], p.weeklyTarget)}<span class="tiny muted">Для большинства оптимально 3: тяговым мышцам нужно ~48 часов на восстановление.</span></div>
      </div>
      <div class="card stack l"><div class="card-head" style="margin:0"><h3>${ico('timer')}Тренировка</h3></div>
        <div class="field"><span>Отдых по умолчанию (своё и свободное)</span>${segBtns('setRest', [[60, '60 с'], [90, '90 с'], [120, '2 мин'], [180, '3 мин']], p.restDefault)}</div>
        ${sw('autoRest', 'Автозапуск отдыха', 'Таймер отдыха стартует сразу после подхода')}
        <div class="row between wrap">${sw('sound', 'Звуковые сигналы', 'Обратный отсчёт 3-2-1 и старт подхода')}<button class="btn btn-sm" data-act="testSound">${ico('volume')}Проверить</button></div>
        <div class="row between wrap">${sw('vibrate', 'Вибрация', vibOk ? 'В конце отдыха и при рекордах' : 'Не поддерживается этим устройством или браузером', !vibOk)}${vibOk ? `<button class="btn btn-sm" data-act="testVib">${ico('vib')}Проверить</button>` : ''}</div>
      </div>
      <div class="card stack l"><div class="card-head" style="margin:0"><h3>${ico('sparkle')}Оформление</h3></div>
        <div class="field"><span>Акцентный цвет</span>${segBtns('setAcc', [['orange', '<i class="sw" style="background:#ff6a1a"></i>Orange Fire'], ['red', '<i class="sw" style="background:#e81e2c"></i>Red Power']], p.accent)}</div>
        <div class="acc-prev" aria-hidden="true"><div class="ap-bar"><i></i></div><div class="tiny muted">Так выглядят прогресс, кнопки и графики. Цвет применяется сразу и сохраняется.</div></div>
      </div>
      <div class="card stack l span2"><div class="card-head" style="margin:0"><h3>${ico('file')}Данные</h3><span class="hint">${fmtNum(kb)} КБ · ${pl(S.sessions.length, ['запись', 'записи', 'записей'])} · ${pl(S.tests.length, W.test)}</span></div>
        <div class="grid g4">
          <div class="card flat stack s"><b>Резервная копия</b><span class="small muted">Скачать все данные в JSON-файл</span><button class="btn btn-sm mt-s" data-act="expJson">${ico('download')}Экспорт</button></div>
          <div class="card flat stack s"><b>Восстановить</b><span class="small muted">Загрузить ранее сохранённый JSON</span><label class="btn btn-sm mt-s">${ico('upload')}Импорт<input type="file" accept="application/json,.json" data-chg="impJson" class="sr"></label></div>
          <div class="card flat stack s"><b>Демо-данные</b><span class="small muted">10 недель тренировок, чтобы посмотреть графики</span><button class="btn btn-sm mt-s" data-act="demoData">${ico('sparkle')}Загрузить</button></div>
          <div class="card flat stack s"><b>Сброс</b><span class="small muted">Удалить все данные из браузера</span><button class="btn btn-sm btn-danger mt-s" data-act="resetAll">${ico('trash')}Сбросить</button></div>
        </div>
        ${STORAGE_OK ? '' : `<div class="note n-bad">${ico('warn')}<div>Хранилище браузера недоступно (например, приватный режим). Данные не сохранятся после закрытия страницы — сделайте экспорт.</div></div>`}
      </div>
      <div class="card span2"><div class="card-head"><h3>${ico('shield')}Безопасность</h3><button class="btn btn-sm btn-ghost" data-act="reOnboard">${ico('refresh')}Показать приветствие</button></div>
        <div class="grid g2"><ol class="ol small">${SAFETY_RULES.map(x => `<li>${x}</li>`).join('')}</ol>
          <div class="stack"><div class="note n-warn">${ico('info')}<div>PULLUP PRO — тренировочный дневник и набор методик, а не медицинская рекомендация. Сроки освоения подтягиваний и выхода силой индивидуальны — приложение не обещает результат за фиксированное число дней.</div></div>
          <div class="small muted">Версия ${APP_VERSION} · работает офлайн · без внешних сервисов и платных API</div></div></div>
      </div>
    </div>`;
  }
};
ACT.setP = el => {
  const f = el.dataset.f; let v = el.value;
  if (f === 'name') v = v.trim().slice(0, 30);
  if (f === 'bodyweight') v = round1(clamp(numVal(el, document, 75), 30, 250));
  if (f === 'goalDaily') v = clamp(Math.round(numVal(el)), 0, 500);
  if (f === 'program' && !PROGM[v]) return;
  S.profile[f] = v; save(); toast('Сохранено', 'ok', 1200); updateShell();
};
ACT.setMax = el => { S.profile.maxPullups = clamp(Math.round(numVal(el)), 0, 100); LG.resetPctAdj(); save(); toast('Максимум обновлён — проценты в программах пересчитаны', 'ok'); LG.checkAch(); };
ACT.setSw = el => { S.profile[el.dataset.f] = el.checked; save(); toast(el.checked ? 'Включено' : 'Выключено', 'ok', 1200); };
ACT.setWeekly = el => { S.profile.weeklyTarget = +el.dataset.v; setSeg(el); save(); toast('Сохранено', 'ok', 1200); };
ACT.setRest = el => { S.profile.restDefault = +el.dataset.v; setSeg(el); save(); toast('Сохранено', 'ok', 1200); };
ACT.setAcc = el => { S.profile.accent = el.dataset.v; save(); applyAccent(); rerender(); };
ACT.testSound = () => { if (!S.profile.sound) return toast('Звук выключен в настройках', 'err'); AUD.tick(); setTimeout(() => AUD.tick(), 450); setTimeout(() => AUD.go(), 900); };
ACT.testVib = () => { if (!S.profile.vibrate) return toast('Вибрация выключена в настройках', 'err'); buzz([120, 80, 120]); toast('Если устройство поддерживает вибрацию, вы её почувствовали', 'info'); };
function applyAccent() { document.body.classList.toggle('acc-red', S.profile.accent === 'red'); const m = $('meta[name=theme-color]'); if (m) m.content = '#09090b'; }
ACT.expJson = () => { download(`pullup-pro-backup-${todayKey()}.json`, JSON.stringify({ app: 'pullup-pro', version: APP_VERSION, exported: new Date().toISOString(), data: S }, null, 1)); toast('Резервная копия скачана', 'ok'); };
ACT.impJson = el => {
  const f = el.files && el.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = async () => {
    el.value = '';
    try {
      const j = JSON.parse(r.result), d = j && j.data ? j.data : j;
      if (!d || typeof d !== 'object' || !d.profile || !Array.isArray(d.sessions)) throw new Error('bad');
      if (!(await confirmBox('Импортировать данные?', `Текущие данные будут заменены данными из файла (${pl(d.sessions.length, ['запись', 'записи', 'записей'])}).`, 'Импортировать', true))) return;
      S = merge(defaultState(), d); save(); applyAccent(); toast('Данные импортированы', 'ok'); LG.checkAch(true); render();
    } catch (e) { toast('Не удалось прочитать файл: это не резервная копия PULLUP PRO', 'err', 4500); }
  };
  r.onerror = () => toast('Ошибка чтения файла', 'err');
  r.readAsText(f);
};
ACT.resetAll = async () => {
  if (!(await confirmBox('Сбросить все данные?', 'Будут удалены тренировки, тесты, планы, достижения и настройки. Рекомендуем сначала сделать экспорт. Отменить нельзя.', 'Удалить всё', true))) return;
  S = defaultState(); save(); runStore.clear(); applyAccent(); toast('Данные удалены', 'ok'); go('#/home'); setTimeout(showOnboarding, 300);
};
ACT.demoData = async () => {
  if ((S.sessions.length || S.tests.length) && !(await confirmBox('Загрузить демо-данные?', 'Текущие тренировки, тесты и планы будут заменены демонстрационными. Профиль (имя, звук, цвет) сохранится.', 'Заменить', true))) return;
  loadDemo(); toast('Демо-данные загружены: 10 недель тренировок', 'ok', 3500); go('#/stats');
};
ACT.reOnboard = () => showOnboarding(true);

/* ---------- demo data: ~10 weeks of plausible progress ---------- */
function loadDemo() {
  let seed = 20240917; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647, ri = (a, b) => a + Math.floor(rnd() * (b - a + 1));
  const keep = S.profile, st = defaultState();
  st.profile = { ...keep, name: keep.name || 'Алекс', bodyweight: 78, program: 'intermediate', maxPullups: 0, goalDaily: 30, weeklyTarget: 3, onboarded: true, disclaimerAccepted: true };
  const P = PROGM.intermediate, t = todayKey(), start = addDays(startOfWeek(new Date()), -10 * 7);
  const maxAt = w => Math.round(5 + w * .62);
  const mkSets = (it, max, w, fatigue) => {
    const e = exOf(it.ex);
    if (Array.isArray(it.reps)) return it.reps.map(r => ({ reps: r, weight: 0, done: true }));
    if (e.type === 'time') return Array.from({ length: it.sets }, () => ({ time: Math.max(5, (it.time || 20) + ri(-3, 6) + w), done: true }));
    const m = /^p(\d+)$/.exec(it.reps || ''), base = m ? Math.max(1, Math.round(max * +m[1] / 100)) : it.reps + (w > 5 ? 1 : 0);
    return Array.from({ length: it.sets }, (_, i) => ({ reps: Math.max(1, base - (i >= it.sets - 1 && fatigue ? 1 : 0)), weight: it.w || 0, done: true }));
  };
  let idx = 0;
  for (let w = 0; w <= 10; w++) {
    const days = rnd() < .2 ? [0, 3] : [0, 2, 4];
    for (const dd of days) {
      const d = addDays(start, w * 7 + dd + (rnd() < .15 ? 1 : 0)), k = dayKey(d);
      if (daysBetween(k, t) < 2) continue;
      const wo = P.workouts[idx % 3], pain = w === 4 && dd === 2, hour = w === 2 && dd === 0 ? 7 : ri(17, 19);
      const items = wo.items.map(it => ({ ex: it.ex, sets: mkSets(it, maxAt(w), w, rnd() < .5) }));
      if (pain) items.forEach((it, i) => { if (i >= 2) it.sets = it.sets.map(s => ({ ...s, done: false })); });
      st.sessions.push({ id: uid() + w + dd, date: k, startedAt: new Date(d.getFullYear(), d.getMonth(), d.getDate(), hour, ri(0, 50)).getTime(), title: `${P.name} · ${wo.name}`, source: 'program', ref: { prog: P.id, idx: idx % 3, w: wo.id },
        durationSec: ri(36, 52) * 60, items, feel: pain ? 2 : ri(3, 5), pain, light: false, notes: pain ? 'Неприятные ощущения в локте — остановился, следующую тренировку сделал легче.' : (rnd() < .15 ? 'Хорошая техника, последний подход тяжело.' : ''), completed: !pain, warmup: rnd() > .1 });
      if (pain) st.daily[dayKey(addDays(d, 1))] = { recovery: true, tasks: { r1: true, r2: true } };
      idx++;
    }
    // quick sets on a free day
    const qd = addDays(start, w * 7 + 5), qk = dayKey(qd);
    if (daysBetween(qk, t) >= 1 && rnd() < .7) st.sessions.push({ id: uid() + 'q' + w, date: qk, startedAt: qd.getTime() + 12 * 3600e3, title: 'Быстрые подтягивания', source: 'quick', ref: null, durationSec: 0, items: [{ ex: 'pullup', sets: Array.from({ length: ri(3, 6) }, () => ({ reps: ri(3, 6), weight: 0, done: true })) }], feel: 0, pain: false, notes: '', completed: true, warmup: false });
  }
  [[0, 5, 40, 6], [3, 7, 46, 8], [6, 9, 52, 10], [9, 11, 58, 12]].forEach(([w, pu, hg, dp]) => { const k = dayKey(addDays(start, w * 7 + 6)); if (k < t) st.tests.push({ id: uid() + 't' + w, date: k, pullups: pu, hang: hg, dips: dp }); });
  st.profile.maxPullups = 11;
  // Muscle-Up: stage 1 done, stage 2 in progress
  st.mu.checks.s1d = true; st.mu.done[1] = dayKey(addDays(start, 9 * 7 + 6));
  const muDay = addDays(new Date(), -3);
  if (!st.sessions.some(s => s.date === dayKey(muDay))) st.sessions.push({ id: uid() + 'mu', date: dayKey(muDay), startedAt: muDay.getTime() + 18 * 3600e3, title: 'Muscle-Up · Этап 2', source: 'mu', ref: { stage: 2 }, durationSec: 41 * 60,
    items: [{ ex: 'explosive', sets: [3, 3, 3, 2, 2].map(r => ({ reps: r, weight: 0, done: true })) }, { ex: 'ctb', sets: [3, 2, 2].map(r => ({ reps: r, weight: 0, done: true })) }, { ex: 'activehang', sets: [25, 25].map(x => ({ time: x, done: true })) }, { ex: 'hollow', sets: [30, 30].map(x => ({ time: x, done: true })) }],
    feel: 4, pain: false, notes: 'Взрывные пошли выше, грудь почти у перекладины.', completed: true, warmup: true });
  // custom workouts
  st.custom = BL_TPL.slice(0, 2).map(tp => ({ id: uid() + tp.name.length, name: tp.name, items: tp.items.map(x => blItem(...x)), created: dayKey(addDays(start, 14)) }));
  // plans: last 2 weeks + next 2 weeks
  for (let i = -13; i <= 14; i++) {
    const d = addDays(new Date(), i), k = dayKey(d); if (![0, 2, 4].includes(wdIdx(d))) continue;
    const j = ((i + 14) / 2 | 0) % 3, done = st.sessions.some(s => s.date === k && s.source !== 'quick');
    (st.plan[k] = st.plan[k] || []).push({ id: uid() + i, kind: 'program', prog: P.id, idx: j, title: `${P.name} · ${P.workouts[j].name}`, done: i < 0 ? done : false });
  }
  st.ui.planCount = Object.values(st.plan).reduce((a, x) => a + x.length, 0);
  st.progress.intermediate = { next: idx % 3, adj: { 'A:2': 1, 'B:2': 1, 'C:0': 1 } };
  st.ui.tip = 3;
  S = st; save(); LG.checkAch(true); applyAccent();
}
