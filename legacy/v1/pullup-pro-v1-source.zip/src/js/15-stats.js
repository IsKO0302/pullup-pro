/* ================= Statistics, levels, achievements ================= */
const STV = { vol: 'reps' };
ROUTES.stats = {
  title: 'Статистика',
  render() {
    const D = LG.derive(), now = new Date(), goal = goalFor(), P = PROGM[S.profile.program] || PROGRAMS[0];
    const wks = Array.from({ length: 12 }, (_, i) => dayKey(addDays(startOfWeek(now), (i - 11) * 7)));
    const wkv = k => D.byWeek[k] || { n: 0, pull: 0, reps: 0, ton: 0, dur: 0 };
    const wkLab = wks.map(k => fmtDayShort(k)), wkTip = wks.map(k => `Неделя с ${fmtDay(k)}`);
    const mx = Object.entries(D.maxSeries).sort((a, b) => a[0] < b[0] ? -1 : 1), tBy = {};
    S.tests.forEach(x => { tBy[x.date] = Math.max(tBy[x.date] || 0, x.pullups || 0); });
    let runBest = 0; const bestLine = mx.map(([, v]) => (runBest = Math.max(runBest, v)));
    const exitMax = (P.exit.find(x => x.metric === 'max') || {}).target;
    const months = Array.from({ length: 6 }, (_, i) => { const d = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; });
    const mv = m => Object.entries(D.byDay).filter(([k]) => k.startsWith(m)).reduce((a, [, v]) => (a.pull += v.pull, a.n += v.workouts, a), { pull: 0, n: 0 });
    const d30 = Array.from({ length: 30 }, (_, i) => dayKey(addDays(now, i - 29)));
    const unlocked = ACH.filter(a => S.ach[a.id]).length, lvPct = (D.xp - D.lvlFrom) / Math.max(1, D.lvlTo - D.lvlFrom);
    const avg = D.tot.workouts ? Math.round(D.tot.pull / D.tot.workouts) : 0;
    const M = LG.muState();
    return pageHead('Статистика <em>и прогресс</em>', 'Графики строятся по вашему журналу и тестам. Наведите или нажмите на график, чтобы увидеть значения.', `<a class="btn" href="#/journal">${ico('list')}Журнал</a>`, 'Аналитика') + `
    <div class="kpis">
      ${kpi('Подтягиваний', fmtNum(D.tot.pull), `в среднем ${avg} за тренировку`, 'prog')}
      ${kpi('Тренировок', D.tot.workouts, `время: ${fmtMin(D.tot.dur)}`, 'cal')}
      ${kpi('Максимум', D.rec.maxPull, D.rec.maxPullDate ? `рекорд · ${fmtDay(D.rec.maxPullDate)}` : (D.rec.maxPull ? 'из профиля' : 'пройдите тест'), 'trophy')}
      ${kpi('Серия', `${D.streak}<small>${plural(D.streak, W.week)}</small>`, `лучшая: ${D.bestStreak}`, 'flame')}
    </div>
    <div class="kpis mt">
      ${kpi('Тоннаж', `${fmtNum(D.tot.ton / 1000)}<small>т</small>`, 'подтягивания × (вес тела + отягощение)', 'weight')}
      ${kpi('Удержания', fmtMin(D.tot.hold), 'висы, планки, уголки', 'timer')}
      ${kpi('Выходы силой', D.tot.mu, D.rec.maxMuSet ? `рекорд подхода: ${D.rec.maxMuSet}` : 'пока впереди', 'zap')}
      ${kpi('Тесты уровня', S.tests.length, S.tests.length ? `последний: ${fmtDayShort([...S.tests].sort((a, b) => a.date < b.date ? 1 : -1)[0].date)}` : 'пройдите первый', 'test')}
    </div>
    <div class="grid g2 mt-l">
      <div class="card"><div class="card-head"><h3>${ico('trophy')}Максимум подтягиваний</h3><span class="hint">тесты и строгие подходы прямым хватом</span></div>
        ${CH.slot({ type: 'line', labels: mx.map(([k]) => fmtDayShort(k)), tips: mx.map(([k]) => fmtDay(k)), series: [{ name: 'Лучший результат', data: bestLine, fmt: v => `${v} ${plural(v, W.rep)}` }, { name: 'Тест уровня', data: mx.map(([k]) => tBy[k] || null), color: '#c2c2cb', dash: [5, 5], noFill: true }],
          goal: exitMax ? { value: exitMax, label: `цель ${P.name}` } : null, legend: true, emptyText: 'Пройдите тест уровня или запишите подход подтягиваний прямым хватом', aria: 'График максимума' }, 240)}</div>
      <div class="card"><div class="card-head"><h3>${ico('cal')}Тренировок в неделю</h3><span class="hint">цель: ${S.profile.weeklyTarget}</span></div>
        ${CH.slot({ type: 'bar', labels: wkLab, tips: wkTip, highlight: 11, series: [{ name: 'Тренировки', data: wks.map(k => wkv(k).n) }], goal: { value: +S.profile.weeklyTarget || 3, label: 'цель' }, emptyText: 'За 12 недель тренировок нет', aria: 'Тренировки по неделям' }, 240)}</div>
      <div class="card"><div class="card-head"><h3>${ico('chart')}Объём по неделям</h3>${segBtns('statVol', [['reps', 'Повторы'], ['ton', 'Тоннаж, кг']], STV.vol)}</div>
        <div id="vol-chart">${volChart(wks, wkLab, wkTip, wkv)}</div></div>
      <div class="card"><div class="card-head"><h3>${ico('sun')}Подтягивания за 30 дней</h3><span class="hint">${goal ? `линия — цель дня ${goal}` : ''}</span></div>
        ${CH.slot({ type: 'bar', labels: d30.map(k => parseDay(k).getDate()), tips: d30.map(k => fmtDayW(k)), highlight: 29, series: [{ name: 'Подтягивания', data: d30.map(k => (D.byDay[k] || {}).pull || 0) }], goal: goal ? { value: goal, label: 'цель' } : null, emptyText: 'За 30 дней подтягиваний нет', aria: 'Подтягивания по дням' }, 240)}</div>
      <div class="card"><div class="card-head"><h3>${ico('cal')}По месяцам</h3><span class="hint">6 месяцев</span></div>
        ${CH.slot({ type: 'bar', labels: months.map(m => MONTHS_S[+m.slice(5) - 1]), tips: months.map(m => `${MONTHS[+m.slice(5) - 1]} ${m.slice(0, 4)}`), highlight: 5, series: [{ name: 'Подтягивания', data: months.map(m => mv(m).pull) }], extra: i => `<div class="tiny muted">Тренировок: ${mv(months[i]).n}</div>`, emptyText: 'Пока нет данных по месяцам', aria: 'Подтягивания по месяцам' }, 240)}</div>
      <div class="card"><div class="card-head"><h3>${ico('grid')}Активность</h3><span class="hint">16 недель</span></div>${heatmap(D)}</div>
    </div>
    <div class="grid g2 mt-l">
      <div class="card"><div class="card-head"><h3>${ico('bolt')}Путь к Muscle-Up</h3><a class="hint link-btn" href="#/mu">Открыть</a></div>
        <div class="timeline">${M.st.map(s => `<div class="tl ${s.done ? 'done' : M.cur && M.cur.n === s.n ? 'cur' : ''}"><span class="dt"></span><div><b class="small">Этап ${s.n} · ${s.title}</b><div class="tiny muted">${s.done ? 'пройден' : M.cur && M.cur.n === s.n ? `в процессе · критерии ${s.met}/${s.crit.length}` : 'впереди'}</div></div><span class="small ${s.done ? 'ok' : 'muted'}">${s.done ? fmtDayShort(S.mu.done[s.n]) : '—'}</span></div>`).join('')}</div></div>
      <div class="card"><div class="card-head"><h3>${ico('star')}Уровень и XP</h3><span class="hint">${fmtNum(D.xp)} XP</span></div>
        <div class="lv row"><div class="lv-badge">${D.level}</div><div class="grow"><div class="lv-title">${esc(D.title)}</div><div class="small muted">до уровня ${D.level + 1}: ${fmtNum(D.lvlTo - D.xp)} XP</div>${pbar(lvPct, 'mt-s')}</div></div>
        <div class="lvl-ladder mt">${TITLES.map(([l, t], i) => { const nx = TITLES[i + 1]; const cur = D.level >= l && (!nx || D.level < nx[0]); return `<div class="lvl-step ${D.level >= l ? 'on' : ''} ${cur ? 'cur' : ''}"><b>${t}</b><span>уровень ${l}+</span></div>`; }).join('')}</div>
        <div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>За что начисляется</th><th style="text-align:right">XP</th></tr></thead><tbody>${XP_RULES.map(([a, b]) => `<tr><td>${a}</td><td style="text-align:right"><b class="acc">${b}</b></td></tr>`).join('')}</tbody></table></div></div>
    </div>
    <div class="card mt-l"><div class="card-head"><h3>${ico('medal')}Достижения</h3><span class="hint">открыто ${unlocked} из ${ACH.length}</span></div>
      ${pbar(unlocked / ACH.length, 'thin mb')}
      <div class="ach-grid">${ACH.map(a => { const [c, t] = a.p(D), on = !!S.ach[a.id]; return `<div class="ach ${on ? 'on' : ''}" title="${esc(a.desc)}"><div class="ai">${ico(on ? a.icon : 'lock')}</div><div class="grow"><div class="an">${a.name}</div><div class="ad">${a.desc}</div>
        ${on ? `<div class="tiny ok mt-s">${ico('check')} ${fmtDay(S.ach[a.id])}</div>` : `${pbar(Math.min(1, c / t), 'thin')}<div class="tiny muted mt-s">${fmtNum(Math.min(c, t))} / ${fmtNum(t)}</div>`}</div></div>`; }).join('')}</div></div>`;
  }
};
function volChart(wks, lab, tip, wkv) {
  const ton = STV.vol === 'ton';
  return CH.slot({ type: 'bar', labels: lab, tips: tip, highlight: 11, series: ton ? [{ name: 'Тоннаж', data: wks.map(k => Math.round(wkv(k).ton)), fmt: v => `${fmtNum(v)} кг` }] : [{ name: 'Подтягивания', data: wks.map(k => wkv(k).pull) }, { name: 'Другие повторы', data: wks.map(k => Math.max(0, wkv(k).reps - wkv(k).pull)), color: '#5f5f6a' }],
    stacked: !ton, legend: !ton, fmt: ton ? (v => v >= 1000 ? `${fmtNum(v / 1000)}т` : fmtNum(v)) : null, emptyText: 'За 12 недель нет объёма', aria: 'Объём по неделям' }, 240);
}
ACT.statVol = el => {
  STV.vol = el.dataset.v; setSeg(el);
  const D = LG.derive(), wks = Array.from({ length: 12 }, (_, i) => dayKey(addDays(startOfWeek(new Date()), (i - 11) * 7))), wkv = k => D.byWeek[k] || { n: 0, pull: 0, reps: 0, ton: 0 };
  const c = $('#vol-chart'); c.innerHTML = volChart(wks, wks.map(k => fmtDayShort(k)), wks.map(k => `Неделя с ${fmtDay(k)}`), wkv); CH.mountAll(c);
};
function heatmap(D) {
  const t = todayKey(), start = addDays(startOfWeek(new Date()), -15 * 7);
  let cells = '';
  for (let i = 0; i < 16 * 7; i++) {
    const k = dayKey(addDays(start, i)), v = D.byDay[k], p = v ? v.pull : 0, w = v ? v.workouts : 0;
    const l = k > t ? 'fut' : p >= 60 ? 'l4' : p >= 35 ? 'l3' : p >= 15 ? 'l2' : (p > 0 || w > 0) ? 'l1' : '';
    cells += `<i class="${l}" title="${fmtDayW(k)}: ${p} подтяг.${w ? `, ${pl(w, W.work)}` : ''}"></i>`;
  }
  return `<div class="heat-wrap"><div class="heat-days">${WD.map((d, i) => `<span>${i % 2 === 0 ? d : ''}</span>`).join('')}</div><div class="heat" style="grid-auto-columns:minmax(13px,1fr)">${cells}</div></div>
    <div class="row between mt"><span class="tiny muted">${fmtDayShort(dayKey(start))} — сегодня</span><span class="row tiny muted" style="gap:4px">меньше <span class="heat" style="display:flex;gap:3px;overflow:visible"><i style="width:12px;min-width:12px"></i><i class="l1" style="width:12px;min-width:12px"></i><i class="l2" style="width:12px;min-width:12px"></i><i class="l3" style="width:12px;min-width:12px"></i><i class="l4" style="width:12px;min-width:12px"></i></span> больше</span></div>`;
}
