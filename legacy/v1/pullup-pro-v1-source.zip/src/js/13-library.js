/* ================= Exercise library ================= */
const LIB = { q: '', cat: 'all', lvl: 'all' };
ROUTES.library = {
  title: id => id && EXM[id] ? EXM[id].name : 'Библиотека',
  render(id) { return id && EXM[id] ? libDetail(EXM[id]) : libList(); }
};
function libFiltered() {
  const q = LIB.q.trim().toLowerCase();
  return EX.filter(e => (LIB.cat === 'all' || e.cat === LIB.cat) && (LIB.lvl === 'all' || (LIB.lvl === 'a' ? e.lvl <= 2 : LIB.lvl === 'b' ? e.lvl === 3 : e.lvl >= 4))
    && (!q || (e.name + ' ' + e.desc + ' ' + e.muscles.join(' ') + ' ' + CATM[e.cat].name).toLowerCase().includes(q)));
}
const exCard = e => `<a class="ex-card" href="#/library/${e.id}">
  <div class="ex-fig">${FIG.tag(e.anim, `data-label="0" data-seed="${e.id}"`)}</div>
  <div class="ex-b"><div class="row between"><span class="tiny muted" style="font-weight:700;text-transform:uppercase;letter-spacing:.06em">${CATM[e.cat].name}</span>${lvlBars(e.lvl)}</div>
  <div class="ex-n">${e.name}</div><div class="ex-m">${e.type === 'time' ? 'На время' : 'На повторы'} · ${e.muscles.slice(0, 2).join(', ')}</div></div></a>`;
function libGrid() {
  const xs = libFiltered();
  return xs.length ? `<div class="ex-grid">${xs.map(exCard).join('')}</div>` : emptyBox('Ничего не найдено', 'Попробуйте другой запрос или сбросьте фильтры.', 'search', '<button class="btn btn-sm" data-act="libReset">Сбросить фильтры</button>');
}
function libList() {
  const cnt = c => EX.filter(e => e.cat === c).length;
  return pageHead('Библиотека <em>упражнений</em>', `${EX.length} ${plural(EX.length, W.ex)} с анимированной техникой, ошибками и дозировкой. Нажмите на карточку, чтобы открыть подробности.`, '', 'Техника') + `
  <div class="lib-tools">
    <label class="search">${ico('search')}<input class="inp" id="lib-q" type="search" placeholder="Поиск: название, мышцы…" value="${esc(LIB.q)}" data-inp="libSearch" aria-label="Поиск упражнений"></label>
    ${segBtns('libLvl', [['all', 'Любая сложность'], ['a', 'Лёгкие'], ['b', 'Средние'], ['c', 'Сложные']], LIB.lvl, 'id="lib-lvl"')}
  </div>
  <div class="chips mb-l" id="lib-cats">${[['all', 'Все', EX.length], ...CATS.map(c => [c.id, c.name, cnt(c.id)])].map(([v, l, n]) => `<button class="chip ${LIB.cat === v ? 'on' : ''}" data-act="libCat" data-c="${v}">${l}<span class="cnt">${n}</span></button>`).join('')}</div>
  <div class="small muted mb" id="lib-count">Показано: ${libFiltered().length}</div>
  <div id="lib-grid">${libGrid()}</div>`;
}
function updLib() { const g = $('#lib-grid'); if (!g) return; g.innerHTML = libGrid(); FIG.mountAll(g); const c = $('#lib-count'); if (c) c.textContent = `Показано: ${libFiltered().length}`; }
ACT.libSearch = el => { LIB.q = el.value; updLib(); };
ACT.libCat = el => { LIB.cat = el.dataset.c; $$('#lib-cats .chip').forEach(c => c.classList.toggle('on', c === el)); updLib(); };
ACT.libLvl = el => { LIB.lvl = el.dataset.v; setSeg(el); updLib(); };
ACT.libReset = () => { LIB.q = ''; LIB.cat = 'all'; LIB.lvl = 'all'; rerender(); };
function libDetail(e) {
  const D = LG.derive(), b = D.best[e.id] || {}, cat = CATM[e.cat];
  const pb = e.type === 'time' ? (b.time ? fmtSec(b.time) : '—') : (b.reps ? pl(b.reps, W.rep) : '—');
  const rel = EX.filter(x => x.cat === e.cat && x.id !== e.id).slice(0, 5);
  const usedIn = PROGRAMS.flatMap(P => P.workouts.filter(w => w.items.some(i => i.ex === e.id)).map(w => `${P.name} · ${w.id}`));
  return `<a class="back" href="#/library">${ico('left')}Библиотека</a>
  <div class="ex-detail">
    <div class="fig-box">${FIG.tag(e.anim, 'data-prog="1" data-land="1"')}
      <div class="row between mt">${speedSeg()}<span class="tiny muted">Нажмите на фигуру — пауза</span></div>
      <div class="small muted mt">Оранжевым подсвечены основные работающие звенья. Подпись показывает текущую фазу движения.</div></div>
    <div class="stack l">
      <div><div class="eyebrow">${cat.name}</div><h1 class="disp" style="font-size:clamp(28px,3.4vw,42px)">${e.name}</h1>
        <div class="row wrap mt-s">${lvlBars(e.lvl)}<span class="badge">${e.type === 'time' ? 'На время' : 'На повторы'}</span>${e.w ? '<span class="badge">Можно с отягощением</span>' : ''}${e.equip ? `<span class="badge b-warn">${e.equip}</span>` : ''}</div></div>
      <p class="tx2" style="margin:0">${e.desc}</p>
      <div class="btns"><button class="btn btn-acc" data-act="stSingle" data-id="${e.id}">${ico('play')}Начать упражнение</button><button class="btn" data-act="addToCustom" data-id="${e.id}">${ico('plus')}В свою тренировку</button></div>
      <div class="card"><div class="card-head"><h3>${ico('list')}Пошаговая техника</h3></div><ol class="ol">${e.steps.map(x => `<li>${x}</li>`).join('')}</ol></div>
      <div class="grid g2">
        <div class="card"><div class="card-head"><h3>${ico('core')}Работающие мышцы</h3></div><div class="tags">${e.muscles.map(x => `<span class="tag">${x}</span>`).join('')}</div></div>
        <div class="card"><div class="card-head"><h3>${ico('repeat')}Дозировка</h3></div><p class="tx2 small" style="margin-bottom:8px">${e.dose}</p><div class="small muted">Ваш лучший результат: <b class="acc">${pb}</b>${b.kg ? ` · +${fmtNum(b.kg)} кг` : ''}</div></div>
      </div>
      <div class="card"><div class="card-head"><h3>${ico('warn')}Частые ошибки</h3></div><ul class="ul small tx2">${e.mistakes.map(x => `<li>${x}</li>`).join('')}</ul></div>
      <div class="note ${e.safety ? 'n-bad' : 'n-warn'}">${ico('shield')}<div><b>Безопасность.</b> ${e.safety || 'Разомнитесь перед выполнением. Остановитесь при боли в суставах — не тренируйтесь через боль.'}</div></div>
      ${usedIn.length ? `<div class="small muted">Входит в программы: ${usedIn.join(', ')}</div>` : ''}
      <div><div class="sec-t">Похожие упражнения</div><div class="chips">${rel.map(x => `<a class="chip" href="#/library/${x.id}">${x.name}</a>`).join('')}</div></div>
    </div>
  </div>`;
}
ACT.addToCustom = el => {
  const id = el.dataset.id, e = exOf(id);
  const mk = () => ({ ex: id, sets: e.def.sets || 3, reps: Array.isArray(e.def.reps) ? 5 : (e.def.reps || 5), time: e.def.time || 20, rest: e.def.rest || S.profile.restDefault, w: 0 });
  openModal({
    title: 'Добавить в тренировку',
    body: `<p class="small muted">${e.name} — ${e.def.sets} × ${e.type === 'time' ? (e.def.time || 20) + ' с' : (Array.isArray(e.def.reps) ? 5 : e.def.reps)}</p>
      <div class="picker-list" style="margin-top:0">${S.custom.map(c => `<button class="pk" data-cid="${c.id}"><span class="li-ico">${ico('build')}</span><span class="pk-n">${esc(c.name)}<span class="pk-c" style="display:block">${c.items.length} ${plural(c.items.length, W.ex)}</span></span>${ico('plus')}</button>`).join('')}
      <button class="pk" data-cid="new"><span class="li-ico acc">${ico('plus')}</span><span class="pk-n">Новая тренировка<span class="pk-c" style="display:block">Создать и открыть в конструкторе</span></span></button></div>`,
    onMount(box, m) {
      box.addEventListener('click', ev => {
        const b = ev.target.closest('[data-cid]'); if (!b) return;
        if (b.dataset.cid === 'new') { const c = { id: uid(), name: `Тренировка ${S.custom.length + 1}`, items: [mk()], created: todayKey() }; S.custom.push(c); save(); LG.checkAch(); m.close(); toast('Тренировка создана', 'ok'); go(`#/builder/${c.id}`); return; }
        const c = S.custom.find(x => x.id === b.dataset.cid); if (!c) return;
        c.items.push(mk()); save(); m.close(); toast(`Добавлено в «${esc(c.name)}»`, 'ok');
      });
    }
  });
};
