/* ================= App shell: router, navigation, shared view helpers ================= */
const ROUTES = {};
const NAV = [
  { r: 'home', t: 'Главная', i: 'home' }, { r: 'programs', t: 'Программы', i: 'prog' }, { r: 'mu', t: 'Muscle-Up', i: 'bolt' },
  { r: 'library', t: 'Библиотека', i: 'book' }, { r: 'journal', t: 'Журнал', i: 'list' }, { r: 'stats', t: 'Статистика', i: 'chart' },
  { r: 'calendar', t: 'Календарь', i: 'cal' }, { r: 'builder', t: 'Конструктор', i: 'build' }, { sep: 1 }, { r: 'settings', t: 'Настройки', i: 'gear' }
];
let CUR = { name: 'home', params: [] };
function parseHash() {
  const parts = (location.hash || '').replace(/^#\/?/, '').split('/').filter(Boolean).map(x => { try { return decodeURIComponent(x); } catch (e) { return x; } });
  return ROUTES[parts[0]] ? { name: parts[0], params: parts.slice(1) } : { name: 'home', params: [] };
}
function go(h) { if (location.hash === h) render(); else location.hash = h; }
function render(keep) {
  const r = parseHash(), R = ROUTES[r.name], view = $('#view');
  const same = keep && CUR.name === r.name && CUR.params.join('/') === r.params.join('/'), y = window.scrollY;
  CUR = r; CH.reset();
  let html;
  try { html = R.render(...r.params); } catch (e) { console.error(e); html = emptyBox('Не удалось открыть раздел', esc(e.message), 'warn', '<a class="btn btn-sm" href="#/home">На главную</a>'); }
  view.innerHTML = html;
  if (!same) { view.style.animation = 'none'; void view.offsetHeight; view.style.animation = ''; }
  FIG.mountAll(view); CH.mountAll(view); animateRings(view);
  try { if (R.mount) R.mount(view, ...r.params); } catch (e) { console.error(e); }
  updateShell();
  const t = typeof R.title === 'function' ? R.title(...r.params) : R.title;
  document.title = (t ? t + ' · ' : '') + 'PULLUP PRO';
  window.scrollTo(0, same ? y : 0);
}
const rerender = () => render(true);
function updateShell() {
  const D = LG.derive(), n = CUR.name, pct = (D.xp - D.lvlFrom) / Math.max(1, D.lvlTo - D.lvlFrom);
  $('#nav').innerHTML = NAV.map(x => x.sep ? '<div class="nav-sep"></div>' : `<a href="#/${x.r}" class="${n === x.r ? 'on' : ''}" ${n === x.r ? 'aria-current="page"' : ''}>${ico(x.i)}<span>${x.t}</span></a>`).join('');
  const tab = (r, i, t) => `<a href="#/${r}" class="${n === r ? 'on' : ''}">${ico(i)}<span>${t}</span></a>`;
  $('#tabbar').innerHTML = tab('home', 'home', 'Главная') + tab('programs', 'prog', 'Программы') +
    `<button class="tab-start" data-act="startMenu" aria-label="Начать тренировку"><span class="ts">${ico('play')}</span><span>Старт</span></button>` + tab('stats', 'chart', 'Статистика') +
    `<button data-act="moreMenu" class="${['home', 'programs', 'stats'].includes(n) ? '' : 'on'}">${ico('more')}<span>Ещё</span></button>`;
  $('#side-level').innerHTML = `<div class="row"><div class="lv-badge sm">${D.level}</div><div class="grow"><div class="tiny muted">Уровень ${D.level}</div><b class="small">${esc(D.title)}</b></div></div>
    ${pbar(pct, 'thin mt')}<div class="tiny muted mt-s">${fmtNum(D.xp)} / ${fmtNum(D.lvlTo)} XP</div>
    <button class="btn btn-acc btn-block btn-sm mt" data-act="startMenu">${ico('play')}Начать тренировку</button>`;
  $('#top-level').innerHTML = `<a href="#/stats" class="row" style="gap:8px"><span class="lv-badge sm" style="width:30px;height:30px;font-size:14px;border-radius:9px">${D.level}</span><span>${fmtNum(D.xp)} XP</span></a>`;
}

/* ---------- shared view helpers ---------- */
const pageHead = (title, sub = '', right = '', eyebrow = '') => `<div class="page-head"><div>${eyebrow ? `<div class="eyebrow">${eyebrow}</div>` : ''}<h1>${title}</h1>${sub ? `<div class="sub">${sub}</div>` : ''}</div>${right ? `<div class="btns">${right}</div>` : ''}</div>`;
const kpi = (l, v, s = '', i = '') => `<div class="kpi"><div class="kpi-l">${i ? ico(i) : ''}${l}</div><div class="kpi-v${String(v).replace(/<[^>]*>/g, '').length > 12 ? ' long' : ''}">${v}</div>${s ? `<div class="kpi-s">${s}</div>` : ''}</div>`;
const emptyBox = (t, s = '', i = 'info', btn = '') => `<div class="empty">${ico(i)}<b>${t}</b>${s}${btn ? `<div class="mt">${btn}</div>` : ''}</div>`;
const SRC = { program: 'Программа', custom: 'Своя', mu: 'Muscle-Up', single: 'Упражнение', free: 'Свободная', manual: 'Вручную', quick: 'Быстрые', test: 'Тест уровня' };
const segBtns = (act, opts, cur, attrs = '') => `<div class="seg" ${attrs}>${opts.map(([v, l]) => `<button type="button" data-act="${act}" data-v="${v}" class="${String(v) === String(cur) ? 'on' : ''}">${l}</button>`).join('')}</div>`;
const setSeg = el => $$('button', el.parentNode).forEach(b => b.classList.toggle('on', b === el));
const goalFor = () => +S.profile.goalDaily || 0;
function xpOfSession(s) { const st = LG.sessStats(s); return Math.round(st.pull * 2 + Math.max(0, st.reps - st.pull - st.mu) + st.hold * .2 + st.mu * 10 + (s.source === 'quick' ? 0 : (s.completed !== false ? 40 : 15))); }
ACT.figSpeed = el => { setSeg(el); const f = el.closest('.fig-box, .modal, .tr-main'); const fe = f && $('[data-fig]', f); if (fe) FIG.setSpeed(fe, +el.dataset.v); };
const speedSeg = () => segBtns('figSpeed', [['0.5', '0.5×'], ['1', '1×'], ['1.5', '1.5×']], '1', 'aria-label="Скорость анимации" style="flex-wrap:nowrap;flex-shrink:0"');

/* ---------- exercise picker ---------- */
function pickExercise(onPick, title = 'Выберите упражнение') {
  const st = { q: '', cat: 'all' };
  const list = () => {
    const q = st.q.trim().toLowerCase();
    const xs = EX.filter(e => (st.cat === 'all' || e.cat === st.cat) && (!q || (e.name + ' ' + e.muscles.join(' ')).toLowerCase().includes(q)));
    return xs.length ? xs.map(e => `<button class="pk" data-pk="${e.id}"><span class="li-ico">${ico(CATM[e.cat].icon)}</span><span class="pk-n">${e.name}<span class="pk-c" style="display:block">${CATM[e.cat].name} · ${e.type === 'time' ? 'на время' : 'на повторы'}</span></span>${lvlBars(e.lvl)}</button>`).join('') : emptyBox('Ничего не найдено', '', 'search');
  };
  openModal({
    title, cls: 'wide',
    body: `<div class="search" style="max-width:none">${ico('search')}<input class="inp" type="search" placeholder="Поиск упражнения" data-pq aria-label="Поиск упражнения"></div>
      <div class="chips mt">${[['all', 'Все'], ...CATS.map(c => [c.id, c.name])].map(([v, l]) => `<button class="chip ${v === 'all' ? 'on' : ''}" data-pc="${v}">${l}</button>`).join('')}</div>
      <div class="picker-list" data-pl>${list()}</div>`,
    onMount(box, m) {
      const pl = $('[data-pl]', box), inp = $('[data-pq]', box);
      inp.addEventListener('input', () => { st.q = inp.value; pl.innerHTML = list(); });
      box.addEventListener('click', e => {
        const c = e.target.closest('[data-pc]'); if (c) { st.cat = c.dataset.pc; $$('[data-pc]', box).forEach(x => x.classList.toggle('on', x === c)); pl.innerHTML = list(); return; }
        const p = e.target.closest('[data-pk]'); if (p) { m.close(); onPick(p.dataset.pk); }
      });
      if (window.innerWidth > 900) setTimeout(() => inp.focus(), 60);
    }
  });
}

/* ---------- start flow ---------- */
function weekMuCount() { const wk = weekKey(new Date()); return S.sessions.filter(s => s.source === 'mu' && weekKey(s.date) === wk).length; }
ACT.startMenu = () => {
  const nw = LG.nextWorkout(), M = LG.muState(), r = LG.readiness();
  const opt = (attrs, icon, t, s, cls = '') => `<button class="opt ${cls}" ${attrs}><span class="li-ico ${cls ? 'acc' : ''}">${ico(icon)}</span><span class="grow"><b>${t}</b><span class="small muted" style="display:block">${s}</span></span>${ico('right', 'muted')}</button>`;
  openModal({
    title: 'Начать тренировку',
    body: `<div class="ready ${r.lvl}"><span class="dotc"></span><div><b>${r.title}</b><div class="small muted">${r.reasons.join(' ')}</div></div></div>
      <div class="sec-t mt-l">Рекомендуем</div>
      ${opt(`data-close data-act="stProg" data-p="${nw.prog.id}" data-i="${nw.idx}"`, 'bolt', `${nw.prog.name} · ${nw.w.name}`, `${nw.w.focus} · ${nw.w.items.length} ${plural(nw.w.items.length, W.ex)}`, 'acc')}
      <div class="sec-t mt-l">Другие варианты</div>
      <div class="stack s">
        ${M.cur ? opt(`data-close data-act="stMu" data-n="${M.cur.n}"`, 'zap', `Muscle-Up · Этап ${M.cur.n}`, M.cur.title) : ''}
        ${S.custom.map(c => opt(`data-close data-act="stCustom" data-id="${c.id}"`, 'build', esc(c.name), `Своя · ${c.items.length} ${plural(c.items.length, W.ex)}`)).join('')}
        ${opt('data-close data-act="stFree"', 'plus', 'Свободная тренировка', 'Добавляйте упражнения по ходу')}
        ${opt('data-close data-act="goLib"', 'book', 'Одно упражнение', 'Выберите в библиотеке')}
        ${opt('data-close data-act="testWizard"', 'test', 'Тест уровня', 'Максимум подтягиваний и вис')}
      </div>`
  });
};
ACT.goLib = () => go('#/library');
ACT.moreMenu = () => {
  const items = [['mu', 'bolt', 'Muscle-Up'], ['library', 'book', 'Библиотека'], ['journal', 'list', 'Журнал'], ['calendar', 'cal', 'Календарь'], ['builder', 'build', 'Конструктор'], ['settings', 'gear', 'Настройки']];
  openModal({ title: 'Разделы', body: `<div class="more-grid">${items.map(([r, i, t]) => `<a href="#/${r}" data-close class="more-t ${CUR.name === r ? 'on' : ''}">${ico(i)}<span>${t}</span></a>`).join('')}</div>` });
};
ACT.stProg = el => { const P = PROGM[el.dataset.p], i = +el.dataset.i || 0; precheck(light => LG.runProgram(P.id, i, light), `${P.name} · ${P.workouts[i].name}`); };
ACT.stMu = el => {
  const n = +el.dataset.n, extra = [], wc = weekMuCount();
  if (wc >= 2) extra.push(`На этой неделе уже ${wc} ${plural(wc, W.work)} Muscle-Up. Рекомендуется не более 2 в неделю.`);
  const last = LG.sortSess(S.sessions).reverse().find(s => s.source === 'mu');
  if (last && daysBetween(last.date, todayKey()) < 2) extra.push('С прошлой тренировки Muscle-Up прошло меньше 48 часов.');
  precheck(light => LG.runMu(n, light), `Muscle-Up · Этап ${n}`, extra);
};
ACT.stCustom = el => { const c = S.custom.find(x => x.id === el.dataset.id); if (!c) return toast('Тренировка не найдена', 'err'); if (!c.items.length) return toast('В тренировке нет упражнений', 'err'); precheck(light => LG.runCustom(c, light), c.name); };
ACT.stFree = () => precheck(() => LG.runFree(), 'Свободная тренировка', [], true);
ACT.stSingle = el => precheck(() => LG.runSingle(el.dataset.id), exOf(el.dataset.id).name, [], true);
ACT.stPlan = el => {
  const p = ((S.plan[el.dataset.k] || []).find(x => x.id === el.dataset.id)); if (!p) return;
  precheck(light => { const r = LG.runFromPlan(p, light); if (r) r.plan = { k: el.dataset.k, id: p.id }; return r; }, p.title);
};
/* Pre-training self-check: pain blocks training, low readiness suggests a light version */
function precheck(build, label, extra = [], noLight = false) {
  const r = LG.readiness(), st = { feel: 0, sleep: '', pain: '' };
  const FEEL = ['Плохо', 'Так себе', 'Норм', 'Хорошо', 'Отлично'];
  const sg = (k, opts) => `<div class="seg" role="group">${opts.map(([v, l]) => `<button type="button" data-pk="${k}" data-v="${v}" class="${st[k] === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  let m;
  const draw = () => {
    const ready = st.pain && st.feel, light = st.pain === 'mild' || (st.feel && st.feel <= 2) || st.sleep === 'lt6' || r.lvl !== 'go' || extra.length;
    let res = '';
    if (st.pain === 'pain') res = `<div class="note n-bad">${ico('warn')}<div><b>Тренировка через боль запрещена.</b> Отдохните сегодня. Если боль острая, не проходит или повторяется — обратитесь к врачу или физиотерапевту.</div></div>`;
    else if (ready && light) res = `<div class="note n-warn">${ico('info')}<div><b>Рекомендуем лёгкую версию</b>${noLight ? '' : ': на 1 подход меньше и −20% повторов'}. Прогрессия в лёгкой тренировке не повышается.</div></div>`;
    else if (ready) res = `<div class="note n-ok">${ico('check')}<div><b>Всё в порядке.</b> Начните с разминки — она встроена в тренировку.</div></div>`;
    m.setBody(`<p class="small muted" style="margin-top:-4px">${esc(label)}</p>
      ${r.lvl !== 'go' || extra.length ? `<div class="ready ${extra.length && r.lvl === 'go' ? 'easy' : r.lvl} mb"><span class="dotc"></span><div><b>${r.lvl === 'go' ? 'Обратите внимание' : r.title}</b><div class="small muted">${[...(r.lvl !== 'go' ? r.reasons : []), ...extra].join(' ')}</div></div></div>` : ''}
      <div class="stack l">
        <div><div class="lbl mb">Как вы себя чувствуете?</div><div class="rate">${FEEL.map((f, i) => `<button type="button" data-pk="feel" data-v="${i + 1}" class="${st.feel === i + 1 ? 'on' : ''}">${i + 1}<small>${f}</small></button>`).join('')}</div></div>
        <div><div class="lbl mb">Сон прошлой ночью</div>${sg('sleep', [['lt6', 'меньше 6 ч'], ['6', '6–7 ч'], ['7', '7+ ч']])}</div>
        <div><div class="lbl mb">Есть боль в суставах или мышцах?</div>${sg('pain', [['no', 'Нет'], ['mild', 'Лёгкий дискомфорт'], ['pain', 'Есть боль']])}</div>
        ${res}
      </div>`);
    if (st.pain === 'pain') m.setFoot(`<button class="btn btn-ghost" data-close>Закрыть</button><button class="btn btn-acc" data-pa="rec">${ico('bed')}День восстановления</button>`);
    else if (!ready) m.setFoot(`<span class="small muted grow">Ответьте на вопросы о самочувствии и боли</span><button class="btn btn-ghost" data-close>Отмена</button>`);
    else if (light && !noLight) m.setFoot(`<button class="btn" data-pa="normal">Обычная версия</button><button class="btn btn-acc" data-pa="light">${ico('play')}Лёгкая версия</button>`);
    else m.setFoot(`<button class="btn btn-ghost" data-close>Отмена</button><button class="btn btn-acc" data-pa="normal">${ico('play')}Начать</button>`);
  };
  m = openModal({
    title: 'Проверка самочувствия',
    onMount(box) {
      box.addEventListener('click', e => {
        const b = e.target.closest('[data-pk]');
        if (b) { const k = b.dataset.pk, v = k === 'feel' ? +b.dataset.v : b.dataset.v; st[k] = v; AUD.tap(); draw(); return; }
        const a = e.target.closest('[data-pa]'); if (!a) return;
        if (a.dataset.pa === 'rec') { const k = todayKey(); S.daily[k] = { ...(S.daily[k] || {}), recovery: true }; save(); LG.checkAch(); m.close(); toast('Включён день восстановления. Берегите себя!', 'ok'); rerender(); return; }
        const run = build(a.dataset.pa === 'light'); m.close();
        if (!run) return toast('Не удалось подготовить тренировку', 'err');
        run.check = { feel: st.feel, sleep: st.sleep, pain: st.pain };
        TR.start(run);
      });
    }
  });
  draw();
}
