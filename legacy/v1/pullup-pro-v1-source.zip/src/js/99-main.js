/* ================= Boot: onboarding, resume banner, router start ================= */
function showResume() {
  const rr = $('#resume-root'); if (!rr) return;
  const r = runStore.get();
  if (!r || TR.active() || !Array.isArray(r.items)) { rr.innerHTML = ''; return; }
  const done = r.items.reduce((a, it) => a + (it.sets || []).filter(s => s.done === true).length, 0);
  const ms = (r.activeMs || 0) + (r.paused ? 0 : Math.max(0, (r.savedAt || r.tickAt) - r.tickAt));
  rr.innerHTML = `<div class="resume" role="status">${ico('timer', 'acc')}<div class="grow"><b>Незавершённая тренировка</b><div class="small muted">${esc(r.title)} · ${pl(done, W.set)} · ${fmtClock(ms / 1000)}</div></div>
    <button class="btn btn-sm btn-acc" data-act="resumeRun">${ico('play')}Продолжить</button><button class="btn btn-sm btn-ghost" data-act="dropRun">Удалить</button></div>`;
}
ACT.resumeRun = () => TR.resume();
ACT.dropRun = async () => { if (await confirmBox('Удалить незавершённую тренировку?', 'Выполненные в ней подходы не сохранятся в журнал.', 'Удалить', true)) { runStore.clear(); showResume(); toast('Удалено', 'ok'); } };

function showOnboarding(again) {
  const st = { step: 0, ok: !!again, name: S.profile.name || '', bw: S.profile.bodyweight || 75, max: S.profile.maxPullups || 0, goal: S.profile.goalDaily || 20 };
  let m;
  const dots = () => `<div class="steps-dots">${[0, 1, 2].map(i => `<i class="${i <= st.step ? 'on' : ''}"></i>`).join('')}</div>`;
  const draw = () => {
    if (st.step === 0) {
      m.setTitle('Добро пожаловать в PULLUP PRO');
      m.setBody(dots() + `<div class="row top"><div style="width:120px;flex-shrink:0">${FIG.tag('muscleup', 'data-label="0"')}</div>
        <div><p class="tx2" style="margin-top:4px">Платформа для тренировок подтягиваний и выхода силой: программы трёх уровней, путь к Muscle-Up из 6 этапов, таймеры, журнал и статистика.</p>
        <div class="ob-feat">${[['prog', 'Программы с прогрессией'], ['bolt', '6 этапов Muscle-Up'], ['timer', 'Таймер отдыха и счётчик'], ['chart', 'Графики и рекорды']].map(([i, t]) => `<div>${ico(i, 'acc')}${t}</div>`).join('')}</div></div></div>
        <div class="note n-warn mt">${ico('shield')}<div><b>Безопасность.</b><ul class="ul mt-s small">${SAFETY_RULES.slice(0, 5).map(x => `<li>${x}</li>`).join('')}</ul></div></div>
        <label class="check mt"><input type="checkbox" data-ob="ok" ${st.ok ? 'checked' : ''}><span class="box">${ico('check')}</span><span class="ct">Я ознакомился с правилами безопасности и понимаю, что приложение не заменяет консультацию врача или тренера<span class="cs">При травмах, болезнях сердца или давления — сначала проконсультируйтесь со специалистом</span></span></label>`);
      m.setFoot(`<span class="small muted grow">${st.ok ? '' : 'Отметьте согласие, чтобы продолжить'}</span><button class="btn btn-acc" data-ob="next" ${st.ok ? '' : 'disabled'}>Далее ${ico('right')}</button>`);
    } else if (st.step === 1) {
      const rec = PROGM[levelForMax(st.max)];
      m.setTitle('Ваш профиль');
      m.setBody(dots() + `<div class="form-grid">
        <label class="field"><span>Имя (необязательно)</span><input class="inp" maxlength="30" data-ob="name" value="${esc(st.name)}" placeholder="Как к вам обращаться"></label>
        <div class="field"><span>Вес тела, кг</span>${stepper('ob-bw', st.bw, 30, 250, 0.5, 'data-ob="bw"')}</div>
        <div class="field"><span>Сколько раз подтягиваетесь сейчас?</span>${stepper('ob-max', st.max, 0, 100, 1, 'data-ob="max"')}<span class="tiny muted">Строго, без раскачки. Не уверены — укажите 0 и пройдите тест.</span></div>
        <div class="field"><span>Цель: подтягиваний в день</span>${stepper('ob-goal', st.goal, 0, 500, 5, 'data-ob="goal"')}</div></div>
        <div class="note n-acc mt" id="ob-rec">${ico('prog')}<div>Рекомендуемая программа: <b>${rec.name}</b> — ${rec.title.toLowerCase()} (${rec.range}).</div></div>`);
      m.setFoot(`<button class="btn btn-ghost" data-ob="back">Назад</button><button class="btn btn-acc" data-ob="next">Далее ${ico('right')}</button>`);
    } else {
      const rec = PROGM[levelForMax(st.max)];
      m.setTitle('Всё готово');
      m.setBody(dots() + `<div class="card accent"><div class="prog-range">${rec.range}</div><div class="prog-name">${rec.name}</div><p class="small tx2" style="margin:6px 0 0">${rec.desc}</p>
        <div class="row wrap mt-s"><span class="badge">${ico('cal')}${rec.freq}</span><span class="badge">${ico('clock')}${rec.dur}</span></div></div>
        <p class="small muted mt">Данные хранятся только в этом браузере. Резервную копию можно сделать в настройках.</p>
        <div class="stack s">
          <button class="opt acc" data-ob="finish"><span class="li-ico acc">${ico('play')}</span><span class="grow"><b>Начать с чистого листа</b><span class="small muted" style="display:block">Ваш собственный журнал с первого дня</span></span>${ico('right', 'muted')}</button>
          <button class="opt" data-ob="test"><span class="li-ico">${ico('test')}</span><span class="grow"><b>Пройти тест уровня</b><span class="small muted" style="display:block">Точно определить максимум и программу</span></span>${ico('right', 'muted')}</button>
          <button class="opt" data-ob="demo"><span class="li-ico">${ico('sparkle')}</span><span class="grow"><b>Посмотреть на демо-данных</b><span class="small muted" style="display:block">10 недель тренировок для знакомства; можно сбросить в настройках</span></span>${ico('right', 'muted')}</button>
        </div>`);
      m.setFoot(`<button class="btn btn-ghost" data-ob="back">Назад</button>`);
    }
  };
  const commit = () => {
    Object.assign(S.profile, { name: st.name.trim().slice(0, 30), bodyweight: round1(clamp(st.bw, 30, 250)), maxPullups: clamp(Math.round(st.max), 0, 100), goalDaily: clamp(Math.round(st.goal), 0, 500), program: levelForMax(st.max), onboarded: true, disclaimerAccepted: true });
    save();
  };
  m = openModal({
    title: '', dismiss: !!again,
    onMount(box) {
      box.addEventListener('click', e => {
        const b = e.target.closest('[data-ob]'); if (!b || b.tagName === 'INPUT' || b.disabled) return; const a = b.dataset.ob;
        if (a === 'next') { st.step++; draw(); }
        else if (a === 'back') { st.step--; draw(); }
        else if (a === 'finish') { commit(); m.close(); toast(`Профиль сохранён. Программа: ${PROGM[S.profile.program].name}`, 'ok'); render(); }
        else if (a === 'test') { commit(); m.close(); render(); setTimeout(() => ACT.testWizard(), 250); }
        else if (a === 'demo') { commit(); m.close(); loadDemo(); toast('Демо-данные загружены. Сбросить можно в настройках.', 'ok', 4000); go('#/home'); }
      });
      box.addEventListener('change', e => { if (e.target.dataset.ob === 'ok') { st.ok = e.target.checked; draw(); } });
      box.addEventListener('input', e => {
        const f = e.target.dataset.ob; if (!f || f === 'ok') return;
        if (f === 'name') st.name = e.target.value; else st[f] = numVal(e.target);
        if (f === 'max') { const r = $('#ob-rec', box), rec = PROGM[levelForMax(st.max)]; if (r) r.innerHTML = `${ico('prog')}<div>Рекомендуемая программа: <b>${rec.name}</b> — ${rec.title.toLowerCase()} (${rec.range}).</div>`; }
      });
    }
  });
  draw();
}

(function boot() {
  $('#brand-mark').innerHTML = ico('bar');
  applyAccent();
  LG.checkAch(true);
  window.addEventListener('hashchange', () => render());
  if (!location.hash) history.replaceState(null, '', '#/home');
  render(); showResume();
  if (!S.profile.onboarded) setTimeout(() => showOnboarding(false), 300);
  window.addEventListener('storage', e => { if (e.key === STORE_KEY && !TR.active()) { S = loadState(); DATA_VER++; render(); } });
})();
