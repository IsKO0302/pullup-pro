/* ================= Home dashboard ================= */
let MOTTO_T = 0;
ROUTES.home = {
  title: 'Главная',
  render() {
    const D = LG.derive(), P = PROGM[S.profile.program] || PROGRAMS[0], nw = LG.nextWorkout(), r = LG.readiness(), t = todayKey();
    const dp = LG.dayPull(t), goal = goalFor(), dt = LG.dailyTasks(t), M = LG.muState();
    const h = new Date().getHours(), greet = h < 5 ? 'Доброй ночи' : h < 12 ? 'Доброе утро' : h < 18 ? 'Добрый день' : 'Добрый вечер';
    const items = LG.planItems(nw.w.items, { prog: nw.prog.id, w: nw.w.id });
    const lvPct = (D.xp - D.lvlFrom) / Math.max(1, D.lvlTo - D.lvlFrom);
    const quickToday = S.sessions.find(s => s.source === 'quick' && s.date === t);
    // last 7 days chart
    const days = Array.from({ length: 7 }, (_, i) => dayKey(addDays(new Date(), i - 6)));
    const ch7 = CH.slot({ type: 'bar', labels: days.map(k => WD[wdIdx(parseDay(k))]), tips: days.map(k => fmtDayW(k)), highlight: 6,
      series: [{ name: 'Подтягивания', data: days.map(k => (D.byDay[k] || {}).pull || 0) }], goal: goal ? { value: goal, label: 'цель' } : null,
      emptyText: 'За последние 7 дней подтягиваний нет — начните с тренировки или быстрого добавления', aria: 'Подтягивания за 7 дней' }, 210);
    const recs = LG.records().filter(x => ['max', 'day', 'hang', 'kg'].includes(x.k));
    const plans = upcomingPlans(4);
    const ach = Object.keys(S.ach).length;
    return `
    <section class="hero">
      <div class="hero-l">
        <div class="eyebrow">${greet}${S.profile.name ? ', ' + esc(S.profile.name) : ''}</div>
        <h1>Тянись<span>выше</span></h1>
        <div class="hero-motto" id="motto">${MOTTOS[(new Date().getDate() + h) % MOTTOS.length]}</div>
        <div class="hero-sub">${r.title}. ${r.reasons[0]}</div>
        <div class="hero-cta">
          <button class="btn btn-acc btn-lg" data-act="startMenu">${ico('play')}Начать тренировку</button>
          <button class="btn btn-lg" data-act="testWizard">${ico('test')}Тест уровня</button>
        </div>
        <div class="hero-chips">
          <a class="badge b-acc" href="#/programs/${P.id}">${ico('prog')}${P.name}</a>
          <span class="badge">${ico('trophy')}Максимум: ${D.curMax}</span>
          <span class="badge">${ico('flame')}Серия: ${pl(D.streak, W.week)}</span>
        </div>
      </div>
      <div class="hero-r">${FIG.tag('hero', 'data-label="0"')}</div>
    </section>

    <div class="grid g3 mt-l">
      <div class="card accent">
        <div class="card-head"><h3>${ico('bolt')}Следующая тренировка</h3><a class="hint link-btn" href="#/programs/${nw.prog.id}">${nw.prog.name}</a></div>
        <div class="lv-title">${nw.w.name}</div><div class="eyebrow-s">${nw.w.focus}</div>
        <div class="next-ex">${items.map(it => `<div><span>${exOf(it.ex).name}</span><span>${LG.doseText(it)}</span></div>`).join('')}</div>
        <div class="ready ${r.lvl}"><span class="dotc"></span><div><b>${r.title}</b><div class="small muted">${r.reasons.join(' ')}</div></div></div>
        <button class="btn btn-acc btn-block mt" data-act="stProg" data-p="${nw.prog.id}" data-i="${nw.idx}">${ico('play')}Начать: ${nw.w.name}</button>
      </div>

      <div class="card">
        <div class="card-head"><h3>${ico('target')}Цель дня</h3><a class="hint link-btn" href="#/settings">Изменить</a></div>
        ${dt.rec ? `<div class="note n-acc">${ico('bed')}<div><b>День восстановления.</b> Подтягивания сегодня не планируются — лёгкая мобилити и отдых.</div></div>` : `
        <div class="goal-ring-row">
          ${ring(goal ? dp / goal : 0, 132, 12, `<div><div class="rg-v">${dp}</div><div class="rg-l">из ${goal || '—'}</div></div>`, goal && dp >= goal ? 'ok' : '')}
          <div class="grow stack s">
            <div class="small muted">${goal && dp >= goal ? `<b class="ok">Цель выполнена!</b> Отличная работа.` : goal ? `Осталось ${pl(Math.max(0, goal - dp), W.pull)}. Добавьте подходы, сделанные без таймера:` : 'Задайте дневную цель в настройках.'}</div>
            <div class="quick">${[1, 3, 5, 10].map(n => `<button class="btn btn-sm" data-act="quickAdd" data-n="${n}" aria-label="Добавить ${n}">+${n}</button>`).join('')}</div>
            ${quickToday ? `<button class="link-btn small" style="align-self:flex-start" data-act="quickUndo">${ico('refresh')} Отменить последнее</button>` : ''}
          </div>
        </div>`}
        <div class="divider"></div>
        <div class="row between"><b class="small nowrap">Задачи дня · ${dt.done}/${dt.list.length}</b>
          <label class="switch small"><input type="checkbox" data-chg="recToggle" ${dt.rec ? 'checked' : ''}><i></i><span>Восстановление</span></label></div>
        <div class="mt-s tasks">${dt.list.map(x => x.auto ? `<div class="check auto ${x.done ? 'met' : ''}"><span class="box">${ico('check')}</span><span class="ct">${x.t}<span class="cs">Отмечается автоматически: ${dp} из ${goal}</span></span></div>` : checkbox('dayTask', x.done, x.t, '', `data-id="${x.id}"`)).join('')}</div>
      </div>

      <div class="card level-card">
        <div class="card-head"><h3>${ico('star')}Уровень</h3><a class="hint link-btn" href="#/stats">Статистика</a></div>
        <div class="lv"><div class="lv-badge">${D.level}</div><div class="grow"><div class="lv-title">${esc(D.title)}</div><div class="small muted">${fmtNum(D.xp)} XP · до уровня ${D.level + 1}: ${fmtNum(D.lvlTo - D.xp)} XP</div></div></div>
        ${pbar(lvPct, 'mt')}
        <div class="mini3 mt">
          <div class="rec"><div class="rv">${fmtNum(D.tot.pull)}</div><div class="rl">подтягиваний</div></div>
          <div class="rec"><div class="rv">${D.tot.workouts}</div><div class="rl">${plural(D.tot.workouts, W.work)}</div></div>
          <div class="rec"><div class="rv">${ach}<small class="muted" style="font-size:13px">/${ACH.length}</small></div><div class="rl">достижений</div></div>
        </div>
        <div class="divider"></div>
        <div class="row">
          ${ring(M.pct, 76, 8, `<div class="rg-v" style="font-size:17px">${Math.round(M.pct * 100)}%</div>`)}
          <div class="grow"><b>Путь к Muscle-Up</b><div class="small muted">${M.cur ? `Этап ${M.cur.n} из 6 · ${M.cur.title} · критерии ${M.cur.met}/${M.cur.crit.length}` : 'Все 6 этапов пройдены!'}</div><a class="link-btn small" href="#/mu">Открыть путь</a></div>
        </div>
      </div>
    </div>

    <div class="kpis mt-l">
      ${kpi('Подтягиваний', fmtNum(D.tot.pull), `за неделю: ${(D.byWeek[weekKey(new Date())] || {}).pull || 0}`, 'prog')}
      ${kpi('Тренировок', D.tot.workouts, `на этой неделе: ${(D.byWeek[weekKey(new Date())] || {}).n || 0} из ${S.profile.weeklyTarget}`, 'cal')}
      ${kpi('Максимум', D.rec.maxPull, D.rec.maxPullDate ? `рекорд · ${fmtDay(D.rec.maxPullDate)}` : (D.rec.maxPull ? 'из профиля · пройдите тест' : 'пройдите тест уровня'), 'trophy')}
      ${kpi('Серия', `${D.streak}<small>${plural(D.streak, W.week)}</small>`, `лучшая: ${pl(D.bestStreak, W.week)} · 2+ тренировки в неделю`, 'flame')}
    </div>

    <div class="grid g3 mt-l">
      <div class="card span2">
        <div class="card-head"><h3>${ico('chart')}Последние 7 дней</h3><span class="hint">подтягивания по дням${goal ? ` · линия — цель ${goal}` : ''}</span></div>
        ${ch7}
      </div>
      <div class="card">
        <div class="card-head"><h3>${ico('trophy')}Рекорды</h3><a class="hint link-btn" href="#/journal">Журнал</a></div>
        <div class="rec-grid">${recs.map(x => `<div class="rec"><div class="rl">${x.l}</div><div class="rv">${x.v}</div><div class="tiny muted">${x.u ? x.u + ' · ' : ''}${x.d ? fmtDayShort(x.d) : (x.v === '—' ? 'пока нет' : 'из профиля')}</div></div>`).join('')}</div>
      </div>
    </div>

    <div class="grid g2 mt-l">
      <div class="card">
        <div class="card-head"><h3>${ico('cal')}Запланировано</h3><a class="hint link-btn" href="#/calendar">Календарь</a></div>
        ${plans.length ? `<div class="list">${plans.map(([k, p]) => `<div class="li"><div class="li-ico">${ico(p.kind === 'mu' ? 'zap' : p.kind === 'custom' ? 'build' : 'bolt')}</div><div class="li-main"><div class="li-t">${esc(p.title)}</div><div class="li-s">${fmtDayW(k)} · ${relDay(k)}</div></div>${k === t ? `<button class="btn btn-sm btn-acc" data-act="stPlan" data-k="${k}" data-id="${p.id}">${ico('play')}Начать</button>` : ''}</div>`).join('')}</div>`
        : emptyBox('Нет запланированных тренировок', 'Составьте расписание — так проще держать режим.', 'cal', '<a class="btn btn-sm" href="#/calendar">Открыть календарь</a>')}
      </div>
      <div class="card">
        <div class="card-head"><h3>${ico('sparkle')}Совет дня</h3><button class="btn btn-sm btn-ghost" data-act="nextTip">${ico('refresh')}Следующий совет</button></div>
        <div class="tip" id="tip">${TIPS[(S.ui.tip || 0) % TIPS.length]}</div>
        <div class="note n-warn mt">${ico('shield')}<div>Не тренируйтесь через боль. Острая боль в локтях или плечах — сигнал остановиться и отдохнуть.</div></div>
      </div>
    </div>`;
  },
  mount() {
    clearInterval(MOTTO_T);
    let i = (new Date().getDate() + new Date().getHours()) % MOTTOS.length;
    MOTTO_T = setInterval(() => {
      const el = $('#motto'); if (!el) return clearInterval(MOTTO_T);
      el.classList.add('out');
      setTimeout(() => { i = (i + 1) % MOTTOS.length; el.textContent = MOTTOS[i]; el.classList.remove('out'); }, 420);
    }, 6500);
  }
};
function upcomingPlans(n) {
  const t = todayKey(), out = [];
  Object.keys(S.plan).filter(k => k >= t).sort().forEach(k => (S.plan[k] || []).forEach(p => { if (!p.done) out.push([k, p]); }));
  return out.slice(0, n);
}
function quickSession(k, create) {
  let s = S.sessions.find(x => x.source === 'quick' && x.date === k);
  if (!s && create) { s = { id: uid(), date: k, startedAt: Date.now(), title: 'Быстрые подтягивания', source: 'quick', ref: null, durationSec: 0, items: [{ ex: 'pullup', sets: [] }], feel: 0, pain: false, notes: '', completed: true, warmup: false }; S.sessions.push(s); }
  return s;
}
ACT.quickAdd = el => {
  const n = +el.dataset.n, k = todayKey(), goal = goalFor(), before = LG.dayPull(k);
  const s = quickSession(k, true); s.items[0].sets.push({ reps: n, weight: 0, done: true }); save();
  const after = LG.dayPull(k); AUD.tap(); buzz(20);
  toast(`+${n} · сегодня ${pl(after, W.pull)}`, 'ok', 1800);
  if (goal && before < goal && after >= goal) { AUD.done(); toast('Цель дня выполнена! +30 XP', 'xp', 3600); }
  LG.checkAch(); rerender();
};
ACT.quickUndo = () => {
  const s = quickSession(todayKey()); if (!s) return;
  const x = s.items[0].sets.pop();
  if (!s.items[0].sets.length) S.sessions = S.sessions.filter(v => v !== s);
  save(); toast(`Отменено: +${x ? x.reps : 0}`, 'info', 1800); rerender();
};
ACT.dayTask = el => { const k = todayKey(), d = S.daily[k] || (S.daily[k] = {}); d.tasks = d.tasks || {}; d.tasks[el.dataset.id] = el.checked; save(); LG.checkAch(); rerender(); };
ACT.recToggle = el => {
  const k = todayKey(); S.daily[k] = { ...(S.daily[k] || {}), recovery: el.checked }; save();
  toast(el.checked ? 'День восстановления: лёгкая мобилити, сон и прогулка' : 'Режим восстановления выключен', 'ok');
  LG.checkAch(); rerender();
};
ACT.nextTip = () => { S.ui.tip = ((S.ui.tip || 0) + 1) % TIPS.length; save(); const el = $('#tip'); if (el) el.textContent = TIPS[S.ui.tip]; };
