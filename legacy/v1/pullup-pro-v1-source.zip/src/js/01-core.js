'use strict';
/* ================= PULLUP PRO — core utilities ================= */
const APP_VERSION = '1.0.0';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sum = a => a.reduce((x, y) => x + (+y || 0), 0);
const round1 = v => Math.round(v * 10) / 10;
const fmtNum = n => (Math.round((+n || 0) * 10) / 10).toLocaleString('ru-RU');
const plural = (n, f) => { n = Math.abs(Math.round(n)); const a = n % 10, b = n % 100; return f[(a === 1 && b !== 11) ? 0 : (a >= 2 && a <= 4 && (b < 10 || b >= 20)) ? 1 : 2]; };
const pl = (n, f) => `${fmtNum(n)} ${plural(n, f)}`;
const W = {
  rep: ['повтор', 'повтора', 'повторов'], pull: ['подтягивание', 'подтягивания', 'подтягиваний'],
  work: ['тренировка', 'тренировки', 'тренировок'], day: ['день', 'дня', 'дней'], week: ['неделя', 'недели', 'недель'],
  sec: ['секунда', 'секунды', 'секунд'], min: ['минута', 'минуты', 'минут'], set: ['подход', 'подхода', 'подходов'],
  ex: ['упражнение', 'упражнения', 'упражнений'], mu: ['выход', 'выхода', 'выходов'], test: ['тест', 'теста', 'тестов']
};
/* ---------- dates ---------- */
const pad = n => String(n).padStart(2, '0');
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseDay = k => { const [y, m, d] = String(k).split('-').map(Number); return new Date(y, (m || 1) - 1, d || 1); };
const addDays = (d, n) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; };
const startOfWeek = d => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; };
const weekKey = d => dayKey(startOfWeek(typeof d === 'string' ? parseDay(d) : d));
const daysBetween = (a, b) => Math.round((parseDay(b) - parseDay(a)) / 864e5);
const todayKey = () => dayKey(new Date());
const MONTHS = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const MONTHS_G = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const MONTHS_S = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const WD = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const WD_F = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
const wdIdx = d => (d.getDay() + 6) % 7;
const fmtDay = k => { const d = parseDay(k); const y = d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : ''; return `${d.getDate()} ${MONTHS_G[d.getMonth()]}${y}`; };
const fmtDayShort = k => { const d = parseDay(k); return `${d.getDate()} ${MONTHS_S[d.getMonth()]}`; };
const fmtDayW = k => { const d = parseDay(k); return `${WD[wdIdx(d)]}, ${fmtDay(k)}`; };
const relDay = k => { const n = daysBetween(todayKey(), k); if (n === 0) return 'сегодня'; if (n === 1) return 'завтра'; if (n === -1) return 'вчера'; if (n > 1 && n < 7) return `через ${pl(n, W.day)}`; if (n < -1 && n > -7) return `${pl(-n, W.day)} назад`; return fmtDay(k); };
const fmtClock = s => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return h ? `${h}:${pad(m)}:${pad(x)}` : `${pad(m)}:${pad(x)}`; };
const fmtMin = s => { const m = Math.round((s || 0) / 60); if (s > 0 && m < 1) return '&lt;1 мин'; if (m < 60) return `${m} мин`; return `${Math.floor(m / 60)} ч ${pad(m % 60)} мин`; };
const fmtSec = s => { s = Math.round(s || 0); return s >= 60 ? `${Math.floor(s / 60)}:${pad(s % 60)}` : `${s} с`; };

/* ---------- icons ---------- */
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/>',
  prog: '<path d="M6.5 6.5v11M17.5 6.5v11M3.5 9v6M20.5 9v6M6.5 12h11"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  grid: '<rect x="3" y="3" width="7.5" height="7.5" rx="1.8"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.8"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.8"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.8"/>',
  book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5A2.5 2.5 0 0 1 6.5 19H20M9 7h7M9 11h5"/>',
  chart: '<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 6-7"/>',
  cal: '<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  build: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
  gear: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.6 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.6-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  play: '<path d="M7 4.5v15l12.5-7.5z" fill="currentColor"/>',
  pause: '<path d="M7 4.5h3.5v15H7zM13.5 4.5H17v15h-3.5z" fill="currentColor" stroke="none"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>',
  check: '<path d="m4.5 12.5 5 5L19.5 7"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>',
  left: '<path d="m15 5-7 7 7 7"/>', right: '<path d="m9 5 7 7-7 7"/>', up: '<path d="m5 15 7-7 7 7"/>', down: '<path d="m5 9 7 7 7-7"/>',
  trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0z"/><path d="M8 6H5a3 3 0 0 0 3 4.5M16 6h3a3 3 0 0 1-3 4.5M12 13v4M8.5 21h7M9.5 17h5"/>',
  flame: '<path d="M12 2.5c.8 3.6 5 5.2 5 10a5 5 0 0 1-10 0c0-1.9.9-3.3 2-4.4.1 1.8 1 2.9 2 2.9-.2-3.1-.7-5.6 1-8.5z"/>',
  timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 10v3.5l2.5 2.5M9.5 2.5h5M12 2.5V6"/>',
  heart: '<path d="M12 20s-7.5-4.6-7.5-10.3A4.2 4.2 0 0 1 12 7.2a4.2 4.2 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20z"/>',
  warn: '<path d="M12 3.5 2.5 20h19z"/><path d="M12 10v4.5M12 17.2v.3"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8v.3"/>',
  trash: '<path d="M4 7h16M9.5 7V4h5v3M6 7l1 14h10l1-14M10 11v6M14 11v6"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>', upload: '<path d="M12 15V3M7 8l5-5 5 5M4 20h16"/>',
  copy: '<rect x="8.5" y="8.5" width="12" height="12" rx="2.2"/><path d="M15.5 8.5V5a1.5 1.5 0 0 0-1.5-1.5H5A1.5 1.5 0 0 0 3.5 5v9A1.5 1.5 0 0 0 5 15.5h3.5"/>',
  star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',
  medal: '<circle cx="12" cy="15" r="5.5"/><path d="M8.6 10.6 6 3h4l2 5 2-5h4l-2.6 7.6M12 13v4"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.3-4.3L4 9M4 4v5h5M4 13a8 8 0 0 0 14.3 4.3L20 15M20 20v-5h-5"/>',
  volume: '<path d="M4 9.5v5h4l5 4V5.5l-5 4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2.2"/><path d="M8 11V7.5a4 4 0 0 1 8 0V11"/>',
  more: '<circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/>',
  skip: '<path d="M5 5l9 7-9 7z"/><path d="M18 5v14"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11M4.5 6h.01M4.5 12h.01M4.5 18h.01"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  shield: '<path d="M12 3 4.5 6v6c0 4.6 3.2 7.8 7.5 9 4.3-1.2 7.5-4.4 7.5-9V6z"/><path d="m9 12 2 2 4-4"/>',
  weight: '<path d="M7 9h10l2.2 11H4.8z"/><path d="M9.5 9V7.5a2.5 2.5 0 0 1 5 0V9"/>',
  vib: '<rect x="7.5" y="3" width="9" height="18" rx="2"/><path d="M3.5 8v8M20.5 8v8"/>',
  bar: '<path d="M2.5 5h19M5 5v16M19 5v16"/><circle cx="12" cy="10" r="2"/><path d="M9 5l1.5 3.5M15 5l-1.5 3.5M12 12v5"/>',
  test: '<path d="M9 3h6M10 3v6L5 19a1.5 1.5 0 0 0 1.3 2h11.4a1.5 1.5 0 0 0 1.3-2l-5-10V3"/><path d="M7.5 15h9"/>',
  zap: '<path d="M4 14 14 3l-2 8h8L10 21l2-7z"/>',
  bed: '<path d="M3 18V7M3 13h18v5M21 13a3 3 0 0 0-3-3h-7v3"/><circle cx="7" cy="10.5" r="1.8"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  repeat: '<path d="M17 2.5 20.5 6 17 9.5"/><path d="M3.5 11.5V10a4 4 0 0 1 4-4h13M7 21.5 3.5 18 7 14.5"/><path d="M20.5 12.5V14a4 4 0 0 1-4 4h-13"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  file: '<path d="M14 3H6.5A1.5 1.5 0 0 0 5 4.5v15A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/>',
  grip: '<path d="M7 11V6.5a1.5 1.5 0 0 1 3 0V11M10 10.5V5a1.5 1.5 0 0 1 3 0v5.5M13 10.5V6a1.5 1.5 0 0 1 3 0v6M16 9.5a1.5 1.5 0 0 1 3 0V14a7 7 0 0 1-7 7h-.5A6.5 6.5 0 0 1 5 14.5V12a1.5 1.5 0 0 1 2-1.4"/>',
  core: '<rect x="6" y="3" width="12" height="18" rx="4"/><path d="M12 3v18M6.5 9h11M6.5 15h11"/>',
  shoulder: '<path d="M4 20c0-6 3-9 8-9s8 3 8 9"/><circle cx="12" cy="6" r="3"/><path d="M8 13.5 6 20M16 13.5l2 6.5"/>'
};
const ico = (n, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

/* ---------- storage ---------- */
const STORE_KEY = 'pullup.pro.v1';
const RUN_KEY = 'pullup.pro.run';
let STORAGE_OK = true;
const defaultState = () => ({
  v: 1,
  profile: {
    name: '', bodyweight: 75, program: 'beginner', maxPullups: 0, goalDaily: 20, weeklyTarget: 3,
    sound: true, vibrate: true, restDefault: 90, accent: 'orange', onboarded: false, disclaimerAccepted: false,
    created: dayKey(), autoRest: true
  },
  sessions: [], tests: [], mu: { checks: {}, done: {} }, custom: [], plan: {}, ach: {}, daily: {},
  progress: {}, ui: { tip: 0 }
});
function merge(base, data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return base;
  for (const k of Object.keys(data)) {
    if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k]) && data[k] && typeof data[k] === 'object' && !Array.isArray(data[k])) base[k] = merge(base[k], data[k]);
    else base[k] = data[k];
  }
  return base;
}
function loadState() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return defaultState();
    return merge(defaultState(), JSON.parse(raw));
  } catch (e) { STORAGE_OK = false; return defaultState(); }
}
let S = loadState();
let DATA_VER = 1;
function save() {
  DATA_VER++;
  try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); STORAGE_OK = true; }
  catch (e) { if (STORAGE_OK) toast('Не удалось сохранить данные: хранилище браузера недоступно или переполнено', 'err', 5000); STORAGE_OK = false; }
}
const runStore = {
  get() { try { const r = localStorage.getItem(RUN_KEY); return r ? JSON.parse(r) : null; } catch (e) { return null; } },
  set(run) { try { localStorage.setItem(RUN_KEY, JSON.stringify(run)); } catch (e) { } },
  clear() { try { localStorage.removeItem(RUN_KEY); } catch (e) { } }
};
function storageSize() { try { return (localStorage.getItem(STORE_KEY) || '').length * 2; } catch (e) { return 0; } }

/* ---------- sound & vibration ---------- */
const AUD = {
  ctx: null,
  ensure() {
    if (!this.ctx) { const AC = window.AudioContext || window.webkitAudioContext; if (AC) { try { this.ctx = new AC(); } catch (e) { } } }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => { });
    return this.ctx;
  },
  tone(freq, dur, vol = .22, type = 'sine', delay = 0) {
    if (!S.profile.sound) return;
    const c = this.ensure(); if (!c) return;
    const t0 = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + .012); g.gain.exponentialRampToValueAtTime(.0001, t0 + dur);
    o.connect(g); g.connect(c.destination); o.start(t0); o.stop(t0 + dur + .03);
  },
  tick() { this.tone(740, .1, .2, 'sine'); },
  go() { this.tone(988, .16, .26, 'square'); this.tone(1318, .3, .22, 'square', .14); },
  done() { [784, 988, 1175, 1568].forEach((f, i) => this.tone(f, .22, .2, 'triangle', i * .11)); },
  tap() { this.tone(520, .05, .08, 'sine'); },
  warn() { this.tone(330, .25, .25, 'sawtooth'); this.tone(262, .35, .22, 'sawtooth', .22); }
};
const buzz = p => { if (S.profile.vibrate && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) { } } };

/* ---------- toast ---------- */
function toast(msg, kind = 'info', ms = 3200) {
  const root = $('#toasts'); if (!root) return;
  const el = document.createElement('div');
  el.className = 'toast t-' + kind;
  el.innerHTML = `${ico(kind === 'ok' ? 'check' : kind === 'err' ? 'warn' : kind === 'xp' ? 'star' : kind === 'ach' ? 'trophy' : 'info')}<span>${msg}</span>`;
  root.appendChild(el);
  while (root.children.length > 3) root.firstElementChild.remove();
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('in')));
  setTimeout(() => { el.classList.remove('in'); setTimeout(() => el.remove(), 300); }, ms);
}

/* ---------- modal ---------- */
const MODALS = [];
function openModal({ title = '', body = '', foot = '', cls = '', onMount, onClose, dismiss = true }) {
  const root = $('#modal-root');
  const wrap = document.createElement('div');
  wrap.className = 'modal-wrap';
  wrap.innerHTML = `<div class="modal ${cls}" role="dialog" aria-modal="true" aria-label="${esc(String(title).replace(/<[^>]+>/g, ''))}">
    <div class="modal-head"><h3>${title}</h3>${dismiss ? `<button class="btn btn-ghost btn-icon btn-sm" data-close aria-label="Закрыть">${ico('x')}</button>` : ''}</div>
    <div class="modal-body">${body}</div>${foot ? `<div class="modal-foot">${foot}</div>` : ''}</div>`;
  root.appendChild(wrap);
  document.body.classList.add('noscroll');
  const m = {
    el: wrap, box: wrap.querySelector('.modal'), closed: false, dismiss,
    close(v) {
      if (m.closed) return; m.closed = true;
      wrap.classList.remove('in'); setTimeout(() => wrap.remove(), 220);
      MODALS.splice(MODALS.indexOf(m), 1);
      if (!MODALS.length && $('#train-root').hidden) document.body.classList.remove('noscroll');
      onClose && onClose(v);
    },
    setBody(html) { wrap.querySelector('.modal-body').innerHTML = html; FIG.mountAll(wrap); },
    setFoot(html) { let f = wrap.querySelector('.modal-foot'); if (!f) { f = document.createElement('div'); f.className = 'modal-foot'; m.box.appendChild(f); } f.innerHTML = html; f.style.display = html ? '' : 'none'; },
    setTitle(html) { wrap.querySelector('.modal-head h3').innerHTML = html; }
  };
  wrap.addEventListener('click', e => {
    if (dismiss && e.target === wrap) m.close();
    else if (e.target.closest('[data-close]')) m.close();
  });
  MODALS.push(m);
  requestAnimationFrame(() => requestAnimationFrame(() => wrap.classList.add('in')));
  FIG.mountAll(wrap);
  if (onMount) onMount(m.box, m);
  return m;
}
function confirmBox(title, text, okLabel = 'Подтвердить', danger = false) {
  return new Promise(res => {
    openModal({
      title, body: `<p class="tx2">${text}</p>`,
      foot: `<button class="btn btn-ghost" data-close>Отмена</button><button class="btn ${danger ? 'btn-danger' : 'btn-acc'}" data-ok>${okLabel}</button>`,
      onClose: v => res(!!v),
      onMount: (box, m) => { box.querySelector('[data-ok]').addEventListener('click', () => m.close(true)); }
    });
  });
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && MODALS.length) { const m = MODALS[MODALS.length - 1]; if (m.dismiss) { e.preventDefault(); m.close(); } }
});

/* ---------- event delegation ---------- */
const ACT = {};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled || el.classList.contains('disabled')) return;
  const fn = ACT[el.dataset.act];
  if (fn) { e.preventDefault(); AUD.ensure(); fn(el, e); }
});
document.addEventListener('change', e => { const el = e.target.closest('[data-chg]'); if (el && ACT[el.dataset.chg]) ACT[el.dataset.chg](el, e); });
document.addEventListener('input', e => { const el = e.target.closest('[data-inp]'); if (el && ACT[el.dataset.inp]) ACT[el.dataset.inp](el, e); });

/* ---------- small UI helpers ---------- */
function ring(pct, size = 120, sw = 11, inner = '', cls = '') {
  const r = (size - sw) / 2, c = 2 * Math.PI * r, p = clamp(pct, 0, 1);
  return `<div class="ring ${cls}" style="width:${size}px;height:${size}px"><svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><circle class="rg-bg" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="${sw}"/><circle class="rg-fg" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="${sw}" stroke-dasharray="${c}" stroke-dashoffset="${c}" data-off="${c * (1 - p)}"/></svg><div class="rg-c">${inner}</div></div>`;
}
function animateRings(root) { requestAnimationFrame(() => requestAnimationFrame(() => $$('.rg-fg[data-off]', root).forEach(el => { el.style.strokeDashoffset = el.dataset.off; }))); }
const pbar = (pct, cls = '') => `<div class="bar ${cls}"><i style="width:${clamp(pct, 0, 1) * 100}%"></i></div>`;
const lvlBars = n => `<span class="lvl" title="Сложность ${n} из 5">${[1, 2, 3, 4, 5].map(i => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</span>`;
function checkbox(name, checked, text, sub = '', attrs = '') {
  return `<label class="check"><input type="checkbox" ${checked ? 'checked' : ''} ${name ? `data-chg="${name}"` : ''} ${attrs}><span class="box">${ico('check')}</span><span class="ct">${text}${sub ? `<span class="cs">${sub}</span>` : ''}</span></label>`;
}
function stepper(id, val, min = 0, max = 999, step = 1, attrs = '') {
  return `<div class="stepper" data-stepper="${id}" data-min="${min}" data-max="${max}" data-step="${step}"><button type="button" data-act="stepDn" aria-label="Меньше">${ico('minus')}</button><input type="number" inputmode="decimal" id="${id}" value="${val}" min="${min}" max="${max}" step="${step}" ${attrs}><button type="button" data-act="stepUp" aria-label="Больше">${ico('plus')}</button></div>`;
}
ACT.stepUp = el => stepBy(el, 1);
ACT.stepDn = el => stepBy(el, -1);
function stepBy(el, dir) {
  const w = el.closest('[data-stepper]'), inp = w.querySelector('input');
  const st = +w.dataset.step || 1, v = (parseFloat(String(inp.value).replace(',', '.')) || 0) + st * dir;
  inp.value = round1(clamp(v, +w.dataset.min, +w.dataset.max));
  inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
}
const numVal = (sel, root = document, def = 0) => { const el = typeof sel === 'string' ? $(sel, root) : sel; if (!el) return def; const v = parseFloat(String(el.value).replace(',', '.')); return isFinite(v) ? v : def; };
function download(name, content, type = 'application/json') {
  const blob = new Blob([content], { type }), url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500);
}
const hashStr = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
